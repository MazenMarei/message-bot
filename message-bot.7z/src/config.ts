export default {
    token       :"MTE3NTg2MTgxNTA5MjE5OTQ1NA.GV_gCV.YpFJPGSIKlmgWjte6uquKCUvgCMNhloOoQ9lB0",
    prefix      : "-",
    Mongoose    :"mongodb+srv://kils:011maz787@cluster0.d3re0.mongodb.net/Buttons_bot",
    debugMode   : true,
}
