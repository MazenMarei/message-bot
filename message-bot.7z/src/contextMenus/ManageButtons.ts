import {ApplicationCommandType,ComponentEmojiResolvable,MessageContextMenuCommandInteraction, APITextInputComponent, AutocompleteInteraction ,ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, Collection, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle , PermissionFlagsBits, APIEmbed, EmbedData, ButtonComponent, ButtonInteraction, APIMessageComponentButtonInteraction, MessageComponentType, APIActionRowComponent, APIActionRowComponentTypes, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ComponentType, Message, ModalSubmitInteraction, ChannelSelectMenuBuilder, ActionRow, MessageActionRowComponent, ButtonComponentData, BaseButtonComponentData} from "discord.js";
import { MenuPages } from "../utils/menue.js";
import buttonConfig from "../models/button.js";

export default {
    name: "Manage  Button",
    id : "Manage Button",
    type: ApplicationCommandType.Message,
    function: async function ({ interaction }: { interaction: MessageContextMenuCommandInteraction }) {
        const { client } = await import("../index.js");
        let WebhoockMsg = interaction?.targetMessage 
        let getWebhook = (await interaction.guild.fetchWebhooks()).filter(a => a.id === WebhoockMsg.webhookId && a.owner.id === interaction.guild.members.me.id);
        let webhookCommandId = (await interaction.guild.commands.fetch({force : true})).filter(a => a.applicationId === interaction.guild.members.me.id && a.name === "webhook").first();
        
        let Max = false;
        WebhoockMsg.components.map((a,i) => {if(i+1 === 5 && WebhoockMsg.components.length ===  5 && a.components.length == 5) Max = true;})
        if(!interaction.replied) await interaction.deferReply({ephemeral : true});
        if(Max) return interaction.editReply({ content : "وصلت الرساله حدها الاقصي من الازرار"}).catch(err => null);
        if(!getWebhook || getWebhook.size <= 0 ) return interaction.editReply({embeds : [new EmbedBuilder().setColor("Red").setDescription(`## **لا يمكني اضافة زر الي هذه الرساله , يجب علي الرساله ان تكون من صنع __ويب هوك__ وان يكون الويب هوك من __صنع البوت__ (يمكنك صنع ويب هوك من صنع البوت عن طريق استخادم </webhook create:${webhookCommandId.id}>)**`)]}).catch(err => null)
        let MessageRows = WebhoockMsg.components
        if (MessageRows.length >= 5 && MessageRows[4].components.length >= 5) return interaction.editReply({ embeds : [new EmbedBuilder().setColor("Red").setDescription("## لا يمكنني اضافة المزيد من الازرار وصلت الرساله لحدها الاقصي")]}).catch(err => null)
        let MangeOptions = [{label: "حذف زر" , value : "delete" , Emoji : "🗑️"}, {label: "تعديل علي زر" , value : "edit" , Emoji : "⚙️"}]
        let MangeOptionsMenu = await MenuPages({pages : MangeOptions , MenuPlaceholder : "اختر الوظفية التي تريد القيام بها" , menueLimts : {MaxValues : 1 , MinValues : 1} , message : {editReply : true , message : interaction , interaction : interaction as any  } , save : false, cancel : false}) as any
        let MangeType = MangeOptionsMenu.values.flat().find(v => v.value).value

        let AdditionalComponents = []
        let BtnsID = []
        changeUrlBtn(MessageRows,AdditionalComponents)

        


}
}


function changeUrlBtn(MessageRows:ActionRow<MessageActionRowComponent>[] , AdditionalComponents:any[]) {
    let btncount = 0
    for (let row of MessageRows  ) {
        for (let btn of row.components) {
            btncount ++ 
            btn as any
            let newUrlbtn = new ButtonBuilder().setCustomId("UrlBtn"+ btncount).setStyle(3)
            // if(btn).setLabel(btn.data.label)
            
                        
            
        }
        
    }

}

function validURL(str:string) {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
      '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
      '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return !!pattern.test(str);
  }

function isDiscohookUrl(url:string) {
    const validURLPattern = /^(https:\/\/(share\.discohook\.app\/go\/|discohook\.org\/))/;
    return validURLPattern.test(url);
  }


async function getUrldata(url:string) {
    if(isDiscohookUrl(url) === false)  return {Error : true};
    let data = await fetch(url)
    let BufferData = Buffer.from(data.url.replace("https://discohook.org/?data=", ""), "base64")    
    return {Error : false , data : data.url.replace("https://discohook.org/?data=", "")}
}


// function containsSingleEmoji(message:string) {
//     // Define a regular expression pattern for matching emojis
//     const emojiPattern = /[\uD800-\uDBFF][\uDC00-\uDFFF]|\p{Emoji_Presentation}|\p{Emoji}\uFE0F|\p{Emoji}\uFE0E/gu;

//     // Use the match method to find all emojis in the message
//     const emojis = message.match(emojiPattern);

//     // Check if the message contains exactly one emoji
//     if((emojis !== null && emojis.length === 1 && emojis[0] === message) === false )  {
//         let disEmoji = client.emojis.cache?.find(a => a.id === message || a.name === message);
//         if(disEmoji) return {error : false , emoji : disEmoji}
//         else  return {error : true , emoji : disEmoji}
//     } else return {error : emojis !== null && emojis.length === 1 && emojis[0] === message , emoji :message }
// }
async function containsSingleEmoji(message:string) {
    const { client } = await import("../index.js");

    // Define a regular expression pattern for matching emojis
    const emojiPattern = /[\uD800-\uDBFF][\uDC00-\uDFFF]|\p{Emoji_Presentation}|\p{Emoji}\uFE0F|\p{Emoji}\uFE0E/gu;

    // Use the match method to find all emojis in the message
    const emojis = message.match(emojiPattern);

    // Check if the message contains exactly one emoji
    if (emojis !== null && emojis.length === 1 && emojis[0] === message) {
        return { error: false, emoji: message };
    } else {
        // If it's not a single emoji, check if it's a custom emoji from Discord
        let disEmoji = client.emojis.cache?.find((a) => a.id === message || a.name === message);
        if (disEmoji) {
            return { error: false, emoji:disEmoji.id };
        } else {
            return { error: true, emoji: null };
        }
    }
}